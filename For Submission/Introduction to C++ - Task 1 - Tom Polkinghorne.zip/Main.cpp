#include <iostream>
#include "header.h"
#include "String.h"


int main()
{
	std::cout << "Hello World." << std::endl;

	return 0;
}
